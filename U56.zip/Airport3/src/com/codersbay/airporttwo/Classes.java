package com.codersbay.airporttwo;

public class Classes {
	int class_id;
	String name;
	
	public Classes(int class_id, String name) {
		this.class_id = class_id;
		this.name = name;
	}

	public int getClass_id() {
		return class_id;
	}

	public void setClass_id(int class_id) {
		this.class_id = class_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Classes() {
	}
}
